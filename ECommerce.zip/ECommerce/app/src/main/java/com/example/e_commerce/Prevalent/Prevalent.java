package com.example.e_commerce.Prevalent;

import com.example.e_commerce.Model.Users;

public class Prevalent
{
    public static Users onlineUsers;

    public static final String userPhonekey="UserPhone";
    public static final String userPasswordkey="UserPassword";

}
